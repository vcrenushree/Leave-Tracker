<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Form extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url'));
		$this->load->library(array('session', 'form_validation'));
		$this->load->database();
		$this->load->model('Formmodel');
	}
	
	function index()
	{
		// set form validation rules
		$this->form_validation->set_rules('fdate', 'From Date', 'trim|required');
		$this->form_validation->set_rules('tdate', 'To Date', 'trim|required');
		$this->form_validation->set_rules('leavetype', 'Leave Type', 'trim|required');
		$this->form_validation->set_rules('subject', 'Subject', 'trim');
		$this->form_validation->set_rules('note', 'Note', 'trim');
        
		// submit
		if ($this->form_validation->run() == FALSE)
        {
			// fails
			$this->load->view('Form');
        }
		else
		{
			//insert user details into db
			$data = array(
				'uid'=>$this->input->post('uid'),
				'name'=>$this->input->post('uname'),
				'fdate' => $this->input->post('fdate'),
				'tdate' => $this->input->post('tdate'),
				'leavetype' => $this->input->post('leavetype'),
				'subject' => $this->input->post('subject'),
                'note' => $this->input->post('note'),
				'status' =>"pending"
				
			);
			
			if ($this->Formmodel->insert_form($data))
			{
				$this->session->set_flashdata('msg','<div class="alert alert-success text-center">Applied</div>');
				redirect('Form/index');
			}
			else
			{
				// error
				$this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Oops! Error.  Please try again later!!!</div>');
				redirect('Form/index');
			}
		}
	}
}
?>
