<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Adminmodel extends CI_Model
{
	function __construct()
    {
        parent::__construct();
    }
	
	function get_admin($email, $pwd)
	{
		$this->db->where('email', $email);
		$this->db->where('password', $pwd);
        $query = $this->db->get('admin');
		return $query->result();
	}
	// get admin
	function get_user_by_email($email)
	{
		$this->db->where('email', $email);
        $query = $this->db->get('admin');
		return $query->result();
	}
	
	public function get_all_leaves()
{
$this->db->from('leaveform');
$query=$this->db->get();
return $query->result();
}
	
	
}?>