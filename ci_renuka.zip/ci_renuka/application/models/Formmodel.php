<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Formmodel extends CI_Model
{
	function __construct()
    {
        parent::__construct();
    }
	
	
	// get user
	function get_user_by_id($uid)
	{
		$this->db->where('uid', $uid);
        $query = $this->db->get('leaveform');
		return $query->result();
	}
	
	// insert
	function insert_form($data)
    {
		return $this->db->insert('leaveform', $data);
	}
}?>