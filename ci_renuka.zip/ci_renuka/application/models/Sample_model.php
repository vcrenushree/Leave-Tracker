<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
//This is the Book Model for CodeIgniter CRUD using Ajax Application.
class Sample_model extends CI_Model
{
 
	var $table = 'leaveform';
 
 
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
 
 
public function get_all_leaves()
{
$this->db->from('leaveform');
$this->db->order_by("lid" , "desc");
$query=$this->db->get();
return $query->result();
}
 
	 
 public function get_all_leaves_by_id()
{
$this->db->from('leaveform');
$this->db->where('uid', $this->session->userdata('uid'));
$this->db->order_by("lid","desc");
$query=$this->db->get();
return $query->result();
}
 
	
public function delete_by_id($lid)
	{
		$this->db->where('lid', $lid);
		$this->db->delete($this->table);
	}
	
public function approve($lid)
	{
		
		$this->db->set('status', "approved"); 
        $this->db->where('lid', $lid);
        $this->db->update('leaveform');  
					
	}
	
	
public function reject($lid)
	{
		
		$this->db->set('status', "rejected"); 
        $this->db->where('lid', $lid);
        $this->db->update('leaveform');  
			
	}
 
 
}