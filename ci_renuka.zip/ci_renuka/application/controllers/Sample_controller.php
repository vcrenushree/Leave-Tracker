<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
//This is the Controller for codeigniter crud using ajax application.
class Sample_controller extends CI_Controller {
 
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
 
	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Sample_model');
	 	}
 
 
	public function index()
	{
 
		$data['leaveform']=$this->Sample_model->get_all_leaves_by_id();
		$this->load->view('Sample_view',$data);
	}
	
		
 
	public function leave_delete($lid)
	{
		$this->Sample_model->delete_by_id($lid);
		echo json_encode(array("status" => TRUE));
	}
 
	public function approve($lid)
	{
		$this->Sample_model->approve($lid);
		echo json_encode(array("status" => TRUE));
		
	}
 
	public function reject($lid)
	{
		$this->Sample_model->reject($lid);
		echo json_encode(array("status" => TRUE));
		
	}
 
	
 
}