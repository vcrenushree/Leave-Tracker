<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Alogin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url','html'));
		$this->load->library(array('session', 'form_validation'));
		$this->load->database();
		$this->load->model('Adminmodel');
	}
    public function index()
    {
		// get form input
		$email = $this->input->post("email");
        $password = $this->input->post("password");

		// form validation
		$this->form_validation->set_rules("email", "Email-ID", "trim|required");
		$this->form_validation->set_rules("password", "Password", "trim|required");
		
		if ($this->form_validation->run() == FALSE)
        {
			// validation fail
			$this->load->view('Adminlogin_view');
		}
		
		
		
		
		else
		{
			// check for user credentials
			$uresult = $this->Adminmodel->get_admin($email, $password);
			if (count($uresult) > 0)
			{
				//set session
				$sess_data1 = array('alogin' => TRUE, 'email' => $uresult[0]->email, 'password' => $uresult[0]->password);
				$this->session->set_userdata($sess_data1);
				redirect("Admin2/index");
			}
			else
			{
				$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Wrong Email-ID or Password!</div>');
				redirect('Alogin/index');
			}
		}
		
    }
}

?>