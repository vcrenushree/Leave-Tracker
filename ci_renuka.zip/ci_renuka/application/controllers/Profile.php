<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','html'));
		$this->load->library('session');
		$this->load->database();
		$this->load->model('Formmodel');
	}
	
	function index()
	{
		$details = $this->Formmodel->get_user_by_id($this->session->userdata('uid'));
		$data['uid'] = $details[0]->uid ;
		$data['fdate'] = $details[0]->fdate;
		$data['tdate'] = $details[0]->tdate;
		$data['leavetype'] = $details[0]->leavetype;
		$data['subject'] = $details[0]->subject;
		$data['note'] = $details[0]->note;
		$data['status'] = $details[0]->status;
		
		$this->load->view('Profile_view', $data);
	}
}
?>