<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin2 extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url','html'));
		$this->load->library(array('session', 'form_validation'));
		$this->load->database();
		$this->load->model('Sample_model');
	}
    public function index()
    {
		$data['leaveform']=$this->Sample_model->get_all_leaves();
		$this->load->view('Admin2view',$data);
	
    }
	
	
}

?>