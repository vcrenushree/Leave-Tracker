<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Leave Form </title>
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
 --> 
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

</head>
<body>
	
	<script>
	$(document).ready(function(){
		var date_input=$('input[name="fdate"]'); //our date input has the name "fdate"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'yyyy-mm-dd',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script> 
	
	
	<script>
	$(document).ready(function(){
		var date_input=$('input[name="tdate"]'); //our date input has the name "tdate"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'yyyy-mm-dd',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script> 
	
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			
			<a class="navbar-brand" href="<?php echo base_url(); ?>index.php/Sample_controller/index">Back</a>
		</div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<?php if ($this->session->userdata('login')){ ?>
				<li><p class="navbar-text">Hello <?php echo $this->session->userdata('uname'); ?></p></li>
				<li><a href="<?php echo base_url(); ?>index.php/Home/logout">LogOut</a></li>
				<?php } else { ?>
				
				<?php } ?>
			</ul>
		</div>
	</div>
</nav>
<br/>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
		<?php $attributes = array("name" => "leaveform");
			echo form_open("form/index", $attributes);?>
			<legend>Leave Form</legend>
			
			<div class="form-group">
				<label for="uid">Your User-Id</label>
				
				<input class="form-control" name="uid" type="text" value="<?php echo $this->session->userdata('uid');?>" readonly/>
				
			</div>
			
			<div class="form-group">
				<label for="uname">Name</label>
				
				<input class="form-control" name="uname" type="text" value="<?php echo $this->session->userdata('uname');?>" readonly/>
				
			</div>
			
			
			<div class="form-group">
				<label for="date">Date Of leave:</label>
			<br>
				From:<input class="form-control" name="fdate" placeholder="yyyy-mm-dd" type="date" value="<?php echo set_value('fdate'); ?>" />
				<span class="text-danger"><?php echo form_error('fdate'); ?></span>
			</div>
			
			<div class="form-group">
			To:<input class="form-control" name="tdate" placeholder="yyyy-mm-dd" type="date" value="<?php echo set_value('tdate'); ?>" />
				<span class="text-danger"><?php echo form_error('tdate'); ?></span>
			</div>	
				
			<div class="form-group">
				<label for="leavetype">Leave Type</label>

                                <select class="form-control" name="leavetype">
                                <option value="SickLeave">SickLeave</option>
                                <option value="CasualLeave">CasualLeave</option>
                                <option value="EarnedLeave/PL">EarnedLeave/PL</option> 
								
                                </select> 
				
				<span class="text-danger"><?php echo form_error('leavetype'); ?></span>
			</div>
			<div class="form-group">
				<label for="suject">Subject</label>
				<input class="form-control" name="subject" placeholder="Enter the subject" type="text" value="<?php echo set_value('subject'); ?>" />
				<span class="text-danger"><?php echo form_error('subject'); ?></span>
			</div>
			<div class="form-group">
				<label for="note">Note</label>
				<input class="form-control" name="note" placeholder="Leave Note" type="text" value="<?php echo set_value('note'); ?>" />
				<span class="text-danger"><?php echo form_error('note'); ?></span>
			</div>
			<div class="form-group">
				<button name="submit" type="submit" class="btn btn-info">Submit</button>
				<button name="cancel" type="reset" class="btn btn-info">Cancel</button>
			</div>
		<?php echo form_close(); ?>
		<?php echo $this->session->flashdata('msg'); ?>
		</div>
	</div>
	
</div>
	
	
	
	
	
	
<script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
</body>
</html>
