<!DOCTYPE html>
<html>
    
    <head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Leaves Applied </title>
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>">
		<link href="<?php echo base_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
--></head>
  
 <body >
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			
			<a class="navbar-brand" href="<?php echo base_url(); ?>index.php/home">LeaveTracker</a>
		</div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<?php if ($this->session->userdata('login')){ ?>
				<li><p class="navbar-text">Hello <?php echo $this->session->userdata('uname'); ?></p></li>
				
				<li><a href="<?php echo base_url(); ?>index.php/Form">ApplyLeave</a></li>
				<li><a href="<?php echo base_url(); ?>index.php/Home/logout">LogOut</a></li>
				
				<?php } else { ?>
				
				
				<?php } ?>
			</ul>
		</div>
	</div>
</nav>
	
	
 
 
  <div class="container">
   

    <h3>Applied leaves</h3>
    
    <br />
    <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
					<th>Leave ID</th>
					<th>User ID</th>
			        <th>Name</th>
					<th>From Date</th>
					<th>To Date</th>
					<th>Leave Type</th>
			        <th>Subject</th>
			        <th>Note</th>
			        <th>Status</th>
			        
 
          <th style="width:125px;">Action</th>
        </tr>
      </thead>
      <tbody>
				<?php foreach($leaveform as $leaves){?>
				     <tr>
				         <td><?php echo $leaves->lid;?></td>
				         <td><?php echo $leaves->uid;?></td>
						 <td><?php echo $leaves->name;?></td>
						 <td><?php echo $leaves->fdate;?></td>
						 <td><?php echo $leaves->tdate;?></td>
				    	 <td><?php echo $leaves->leavetype;?></td>
						 <td><?php echo $leaves->subject;?></td>
						 <td><?php echo $leaves->note;?></td>
						 <td><?php echo $leaves->status;?></td>
						 <td>
			                   <button class="btn btn-danger" onclick="delete_leave(<?php echo $leaves->lid;?>)"><i class="glyphicon glyphicon-remove"></i></button>
  						 </td>
				      </tr>
		  
				     <?php }?>
 
 
 
      </tbody>
 
      
    </table>
 
  </div>
 
  <script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
 <!-- <script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script> -->
  <script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
 
 
  
	 
<script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
    

    function delete_leave(lid)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
          
			url : "<?php echo site_url('/Sample_controller/leave_delete')?>/"+lid,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });
		  			
       }
    }
 
  </script>
 
 
  </body>
</html>