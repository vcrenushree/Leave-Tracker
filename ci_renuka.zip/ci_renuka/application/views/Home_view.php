<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home Page</title>
	<!--link the bootstrap css file-->
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body background="<?php echo base_url()?>images/5.jpg">
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			
			<a class="navbar-brand" href="<?php echo base_url(); ?>index.php/home">LeaveTracker</a>
		</div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<?php if ($this->session->userdata('login') || $this->session->userdata('alogin')){ ?>
				<li><p class="navbar-text">Hello <?php  if ($this->session->userdata('login'))
                                                             {
														       echo $this->session->userdata('uname');
															 }
														else
															echo "Admin";
					                              ?></p></li>
				<li><a href="<?php echo base_url(); ?>index.php/home/logout">LogOut</a></li>
				<?php } else { ?>
				<li><a href="<?php echo base_url(); ?>index.php/alogin">Admin</a></li>
				<li><a href="<?php echo base_url(); ?>index.php/login">User</a></li>
				<?php } ?>
			</ul>
		</div>
	</div>
</nav>
<br>

			<h2 style="text-align:center;">Leave Tracker</h2><br>
<br>
			<h3 style="text-align:center">Leave tracker allows the employees to apply their requests for vacation, notify sickness or any other type of leave.</h3><br>
                        <h3 style="text-align:center">Admin can either approve or reject his/her leave</h3>
	<br><br><br><br> 
	
<!--	<img src="<?php echo base_url()?>images/5.jpg" alt="open.jpg" align="center" style="margin-top: -107px;"> -->

		
<script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
</body>
</html>
